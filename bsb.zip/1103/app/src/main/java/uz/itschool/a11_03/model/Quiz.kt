package uz.itschool.a11_03.model

class Quiz {
    var score = 0
    private var operator1: Int = 0
    private var operator2: Int = 0
    private var operators = arrayOf("+", "-", "*", "/")
    private var answer: Int = 0
    private var question = ""
    private var operatorIndex = 0

    fun createQuiz(level: Int): String{

        if (level == 1){
            return easyQuiz()
        } else if (level == 2){
            return mediumQuiz()
        } else {
            return hardQuiz()
        }


    }
    fun easyQuiz(): String{
        operator1 = (1..10).random()
        operator2 = (1..10).random()
        operatorIndex = (0..1).random()
        answer = getAnswer()
        question = "$operator1 X $operator2 = ${answer}"

        return question
    }
    fun mediumQuiz(): String{
        operator1 = (10..100).random()
        operator2 = (10..100).random()
        operatorIndex = (0..3).random()
        answer = getAnswer()
        question = "$operator1 X $operator2 = ${answer}"

        return question
    }
    fun hardQuiz(): String{
        operator1 = (100..1000).random()
        operator2 = (100..1000).random()
        operatorIndex = (0..3).random()
        answer = getAnswer()
        question = "$operator1 X $operator2 = ${answer}"

        return question
    }
    fun getAnswer(): Int {
        when (operators[operatorIndex]) {
            "+" -> answer = operator1 + operator2
            "-" -> answer = operator1 - operator2
            "*" -> answer = operator1 * operator2
            "/" -> answer = operator1 / operator2
        }
        return answer
    }

    fun startQuiz(){

    }

    fun checkAnswer(userAnswer: String): Boolean{
        return userAnswer == operators[operatorIndex]
    }

}