package uz.itschool.a11_03.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@Composable
fun LevelScreen(navController: NavHostController) {
    Column(modifier = Modifier.fillMaxSize(),
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
        Row (modifier = Modifier.fillMaxWidth().padding(top = 50.dp, bottom = 50.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.Center){
            Text(text = "Fizika\nFormula", fontWeight = FontWeight.Bold, fontSize = 40.sp, textAlign = TextAlign.Center)
        }
        Row {
            Button(onClick = {
                navController.navigate("quiz/1")
            },colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                Text(text = "Masofani topish")
                //S=vt
            }
        }
        Row {
            Button(onClick = {
                navController.navigate("quiz/2")
            },colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                Text(text = "Potensial enegriya")
                // mgh
            }
        }
        Row {
            Button(onClick = {
                navController.navigate("quiz/3")
            },colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                Text(text = "Kinetik energiya")
                //E=mv^2/2
            }
        }
        Row {
            Button(onClick = {
                navController.navigate("quiz/4")
            },colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                Text(text = "Tok kuchi")
                // I=q/t
            }
        }
        Row {
            Button(onClick = {
                navController.navigate("quiz/5")
            },colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                Text(text = "Aylanish davri")
                //T=t/N
            }
        }
        Row {
            Button(onClick = {
                navController.navigate("quiz/6")
            },colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                Text(text = "Og'irlik kuchi")
                // F=m*g
            }
        }
        Row {
            Button(onClick = {
                navController.navigate("quiz/7")
            },colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                Text(text = "Zanjirning bir qismida bajarilgan ish")
                //A=q*U
            }
        }

    }
}