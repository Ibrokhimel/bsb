package uz.itschool.a11_03.navhost

sealed class NavItem(val route: String) {
    object level: NavItem("Level")
    object quiz: NavItem("Quiz")
}