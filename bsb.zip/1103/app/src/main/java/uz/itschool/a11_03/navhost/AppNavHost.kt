package uz.itschool.a11_03.navhost

import androidx.compose.ui.Modifier
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import uz.itschool.a11_03.screen.LevelScreen
import uz.itschool.a11_03.screen.QuizScreen


@Composable
fun AppNavHost(modifier: Modifier = Modifier, navController: NavHostController,
               startDestinantion: String = NavItem.level.route){
    NavHost(
        modifier = modifier,
        navController = navController,
        startDestination = startDestinantion) {

        composable("quiz/{level}") { navBackStackEntry ->

            val level = navBackStackEntry.arguments?.getString("level")
            level?.let {
                QuizScreen(navController , level)
            }

        }

        composable(NavItem.level.route) {
            LevelScreen(navController)
        }

    }
}