package uz.itschool.a11_03.screen

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import uz.itschool.a11_03.R
import uz.itschool.a11_03.model.Quiz
import uz.itschool.a11_03.navhost.AppNavHost
import java.time.format.TextStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(navController: NavHostController, qlevel : String) {
    val level = remember { mutableStateOf(qlevel.toInt()) }
    val modifier = Modifier
    val velocity = remember {
        mutableIntStateOf(0)
    }
    val time = remember {
        mutableIntStateOf(0)
    }
    val space = remember {
        mutableIntStateOf(0)
    }
    val val1 = remember {
        mutableIntStateOf(0)
    }
    val val2 = remember {
        mutableIntStateOf(0)
    }
    val result = remember {
        mutableIntStateOf(0)
    }
    val quiz = remember {
        Quiz()
    }
    var score = remember {
        mutableStateOf(0)
    }
    var streak = remember {
        mutableStateOf(0)
    }
    var question = remember {
        mutableStateOf(0)
    }
    var currentQuestion = remember {
        mutableStateOf(quiz.createQuiz(level.value))
    }
    var value1 = ""
    var value2 = ""
    var value3 = ""
    var formula = ""
    


    if (level.value == 1) {
        formula = "S=v*t"
        value1 = "Tezlik"
        value2 = "vaqt"
        value3 = "masofa"
        Column(
            modifier = Modifier
                .padding(0.dp, 0.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.Center
        ) {
            Row {
                Text(
                    text = "Velocity: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )


            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val1.intValue.toString(),
                    onValueChange = { try {
                        val1.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val1.intValue = 0
                    }},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row {
                Text(
                    text = "Time: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val2.intValue.toString(),
                    onValueChange = { try {
                        val2.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val2.intValue = 0
                    } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row(
                modifier = Modifier
                    .padding(0.dp, 30.dp, 0.dp, 0.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = {
                    result.intValue = val1.intValue * val2.intValue
                    velocity.intValue = val1.intValue
                    time.intValue = val2.intValue
                    space.intValue = result.intValue
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                    Text(
                        text = "Calc",
                        modifier = Modifier
                            .padding(16.dp),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }

            }
        }
    }
    if (level.value == 2) {
        formula = "E=m*g*h"
        value1 = "Massa"
        value2 = "gravitatsiya"
        value3 = "potensial energiya"
        Column(
            modifier = Modifier
                .padding(0.dp, 0.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.Center
        ) {
            Row {
                Text(
                    text = "Massa: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )


            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val1.intValue.toString(),
                    onValueChange = { try {
                        val1.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val1.intValue = 0
                    }},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row {
                Text(
                    text = "Balandlik: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val2.intValue.toString(),
                    onValueChange = { try {
                        val2.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val2.intValue = 0
                    } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row(
                modifier = Modifier
                    .padding(0.dp, 30.dp, 0.dp, 0.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = {
                    result.intValue = val1.intValue * val2.intValue * 10
                    velocity.intValue = val1.intValue
                    time.intValue = val2.intValue
                    space.intValue = result.intValue
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                    Text(
                        text = "Calc",
                        modifier = Modifier
                            .padding(16.dp),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }

            }
        }
    }
    if (level.value == 3) {
        formula = "E=(mv^2)/2"
        value1 = "Massa"
        value2 = "tezlik"
        value3 = "kinetik energiya"
        Column(
            modifier = Modifier
                .padding(0.dp, 0.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.Center
        ) {
            Row {
                Text(
                    text = "Massa: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )


            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val1.intValue.toString(),
                    onValueChange = { try {
                        val1.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val1.intValue = 0
                    }},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row {
                Text(
                    text = "Tezlik: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val2.intValue.toString(),
                    onValueChange = { try {
                        val2.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val2.intValue = 0
                    } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row(
                modifier = Modifier
                    .padding(0.dp, 30.dp, 0.dp, 0.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = {
                    result.intValue = (val1.intValue * val2.intValue * val2.intValue) / 2
                    velocity.intValue = val1.intValue
                    time.intValue = val2.intValue
                    space.intValue = result.intValue
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                    Text(
                        text = "Calc",
                        modifier = Modifier
                            .padding(16.dp),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }

            }
        }
    }
    if (level.value == 4) {
        formula = "I=q/t"
        value1 = "Zaryad"
        value2 = "vaqt"
        value3 = "tok kuchi"
        Column(
            modifier = Modifier
                .padding(0.dp, 0.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.Center
        ) {
            Row {
                Text(
                    text = "Zaryad: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )


            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val1.intValue.toString(),
                    onValueChange = { try {
                        val1.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val1.intValue = 0
                    }},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row {
                Text(
                    text = "Time: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val2.intValue.toString(),
                    onValueChange = { try {
                        val2.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val2.intValue = 0
                    } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row(
                modifier = Modifier
                    .padding(0.dp, 30.dp, 0.dp, 0.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = {
                    result.intValue = val1.intValue / val2.intValue
                    velocity.intValue = val1.intValue
                    time.intValue = val2.intValue
                    space.intValue = result.intValue
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                    Text(
                        text = "Calc",
                        modifier = Modifier
                            .padding(16.dp),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }

            }
        }
    }
    if (level.value == 5) {
        formula = "T=t/N"
        value1 = "Vaqt"
        value2 = "aylanishlar soni"
        value3 = "aylanish davri"
        Column(
            modifier = Modifier
                .padding(0.dp, 0.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.Center
        ) {
            Row {
                Text(
                    text = "Time: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )


            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val1.intValue.toString(),
                    onValueChange = { try {
                        val1.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val1.intValue = 0
                    }},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row {
                Text(
                    text = "Aylanishlar soni: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val2.intValue.toString(),
                    onValueChange = { try {
                        val2.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val2.intValue = 0
                    } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row(
                modifier = Modifier
                    .padding(0.dp, 30.dp, 0.dp, 0.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = {
                    result.intValue = val1.intValue / val2.intValue
                    velocity.intValue = val1.intValue
                    time.intValue = val2.intValue
                    space.intValue = result.intValue
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                    Text(
                        text = "Calc",
                        modifier = Modifier
                            .padding(16.dp),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }

            }
        }
    }
    if (level.value == 6) {
        value1 = "Massa"
        formula = "F=m*g"
        value2 = "gravitatsiya"
        value3 = "og'irlik kuchi"
        Column(
            modifier = Modifier
                .padding(0.dp, 0.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.Center
        ) {
            Row {
                Text(
                    text = "Massa: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )


            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val1.intValue.toString(),
                    onValueChange = { try {
                        val1.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val1.intValue = 0
                    }},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row {
                Text(
                    text = "Gravitatsiya: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val2.intValue.toString(),
                    onValueChange = { try {
                        val2.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val2.intValue = 0
                    } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row(
                modifier = Modifier
                    .padding(0.dp, 30.dp, 0.dp, 0.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = {
                    result.intValue = val1.intValue * val2.intValue
                    velocity.intValue = val1.intValue
                    time.intValue = val2.intValue
                    space.intValue = result.intValue
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                    Text(
                        text = "Calc",
                        modifier = Modifier
                            .padding(16.dp),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }

            }
        }
    }
    if (level.value == 7) {
        formula = "A=q*U"
        value1 = "Tok kuchlanishi"
        value2 = "zaryad"
        value3 = "zanjirning bir qismi uchun bajarilgan ish"
        Column(
            modifier = Modifier
                .padding(0.dp, 0.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.Center
        ) {
            Row {
                Text(
                    text = "Tok kuchlanishi: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )


            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val1.intValue.toString(),
                    onValueChange = { try {
                        val1.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val1.intValue = 0
                    }},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row {
                Text(
                    text = "Zaryad: ",
                    modifier = Modifier
                        .padding(0.dp)
                        .fillMaxWidth(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
            Row (
                modifier = modifier.padding(horizontal = 50.dp)
            ){
                TextField(
                    value = val2.intValue.toString(),
                    onValueChange = { try {
                        val2.intValue = it.toInt()
                    }
                    catch (ex:Exception){
                        val2.intValue = 0
                    } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number,),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
            Row(
                modifier = Modifier
                    .padding(0.dp, 30.dp, 0.dp, 0.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = {
                    result.intValue = val1.intValue * val2.intValue
                    velocity.intValue = val1.intValue
                    time.intValue = val2.intValue
                    space.intValue = result.intValue
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(255, 165, 0))) {
                    Text(
                        text = "Calc",
                        modifier = Modifier
                            .padding(16.dp),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }

            }
        }
    }



    Row(
        modifier = Modifier
            .fillMaxHeight()
            .padding(0.dp, 0.dp, 0.dp, 200.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.End
    ) {
        Text(
            text = "$value1 ${velocity.intValue} bo'lganda va $value2 ${time.intValue} bo'lganda $value3 ${space.intValue} ga teng bo'ladi",
            modifier = Modifier
                .padding(0.dp)
                .fillMaxWidth(),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )

    }
    Row(modifier = Modifier
        .fillMaxHeight()
        .padding(0.dp, 0.dp, 0.dp, 150.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.End){
        Text(text = formula,
            modifier = Modifier.fillMaxWidth(),
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
//        Row(
//            modifier = Modifier
//                .fillMaxHeight()
//                .padding(0.dp, 0.dp, 0.dp, 200.dp),
//            verticalAlignment = Alignment.Bottom,
//            horizontalArrangement = Arrangement.End
//        ) {
//            Text(
//                text = "${result.value}",
//                modifier = Modifier
//                    .padding(0.dp)
//                    .fillMaxWidth(),
//                fontSize = 28.sp,
//                fontWeight = FontWeight.Bold,
//                textAlign = TextAlign.Center,
//            )
//        }
}
